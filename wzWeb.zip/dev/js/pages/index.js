/**
 * Created by Administrator on 2016/11/2.
 */


$(function () {
    wzWeb.tabSwich($('#news'));  //选项卡
    wzWeb.imgLayer($('.project-list', '#project'));//图片内容遮罩
    wzWeb.imgReload();

    $('#slider').unslider({//首屏轮播
        dots: true,
        fluid: true
    });


    var unslider04 = $('#logos').unslider({
            dots: true
        }),
        data04 = unslider04.data('unslider');

    $('.unslider-arrow06').click(function() {
        var fn = this.className.split(' ')[1];
        data04[fn]();
    });

    // $('#logos').unslider({  //logo轮播
    //     dots: true
    // });
});


wzWeb.imgReload = function () {
    var imgHeight = 0;
    var wtmp = $("body").width();
    var slider = $('ul', '#slider').children('li');
    $(slider).each(function () {
        $(this).css({width: wtmp + "px"});
    });
    $(".sliderimg").each(function () {
        $(this).css({width: wtmp + "px"});
        imgHeight = $(this).height();
    });
};

$(window).resize(function () {
    imgReload();
});


